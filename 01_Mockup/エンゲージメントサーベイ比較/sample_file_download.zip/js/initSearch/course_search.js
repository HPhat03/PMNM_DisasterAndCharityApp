/**
 * Enquete Result Compare
 * Set hidden values
 */
// import * as data from "../TestData";
function enqResCmpValue(cpcc,ccf,cct,eif,eit) {

    $("#course_publisher_company_code").val(cpcc);
    $("#course_code1").val(ccf);
    $("#course_code2").val(cct);
    $("#enquete_id1").val(eif);
    $("#enquete_id2").val(eit);
}



courseSearch = () => {

    $('#result').html('');
    res = enquetes;

    ccode = $('#course_code').val();
    if(ccode != ''){
        res = res.filter((x) => {
            return x.from.code.toLowerCase().includes(ccode.toLowerCase()) || x.to.code.toLowerCase().includes(ccode.toLowerCase())
        })
    }

    all = $("#course_name_radio-0:checked").val() === '0' ? true : false;
    cname = $('#course_name').val();
    if(cname != ''){
        res = res.filter((x) => {
            if(all)
                return x.from.name==cname || x.to.name==cname;
            else
                return x.from.name.toLowerCase().includes(cname.toLowerCase()) || x.to.name.toLowerCase().includes(cname.toLowerCase());
        })
    }
    console.log(res.length === 0);
    if(res.length === 0)
    {
        $('#result').html(`<div class="kc-co-content-box kc-co-no-data-list kc-co-mt30 kc-co-mb30">検索結果がありませんでした。</div>`)
    }
    else{
        overallHtml = html_format_start;
        for(i = 0; i<res.length; i++){
            if(i%2 === 0)
                suffix = 'even';
            else
                suffix = 'odd'

            overallHtml += 
            `
                <tr class="kc-co-table-line-${suffix}">
                    <td style="word-wrap:break-word;word-break:break-all;">
                    ${res[i].from.name} (${res[i].from.code})
                    </td>
                    <td style="word-wrap:break-word;word-break:break-all;">
                    ${res[i].to.name} (${res[i].to.code})
                    </td>

                    <td rowspan="2">
                    <div class="kc-co-td-button">
                        <div class="kc-co-btn-wrap2">
                        <div class="kc-co-btn-wrap1">
                            <div class="kc-co-btn">
                            <a href="javascript:void(0);"
                                onclick="//enqResCmpValue(&#39&#39;,&#39;ESCourse01&#39;,&#39;ESCourse02&#39;,&#39;71&#39;,&#39;71&#39;);submitForm(&#39;/icm/enquete-result-compare/init-view&#39;);return false;"><button
                                class="kc-co-btn-style kc-co-btn-style-text kc-co-btn-small"
                                type="button">表示</button></a>
                            </div>
                        </div>
                        </div>
                    </div>
                    </td>

                </tr>
                <tr class="kc-co-table-line-${suffix}">
                    <td>
                    ${res[i].from.enquete_name} (${res[i].from.enquete_code})
                    </td>
                    <td>
                    ${res[i].to.enquete_name} (${res[i].to.enquete_code})
                    </td>

                </tr>
            `
        }
        overallHtml += html_format_end;

        $('#result').html(overallHtml);
    }
    
    $('#searchResultList').css('display', 'block');
}

html_format_start = `
                <div class="kc-co-hr">
                  <hr>
                </div>
                <div class="kc-co-search_count kc-co-pull-right">
                  検索結果&nbsp;:&nbsp;7件中&nbsp;1件目～7件目表示&nbsp;&nbsp;
                  表示件数&nbsp;:&nbsp;
                  <select id="perPage"
                    onchange="javascript:clearElementValue([&#39;pageId&#39;]);submitForm(&#39;/icm/enquete-result-compare/search/&#39;);"
                    name="perPage">
                    <option value="20" selected="selected">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="200">200</option>
                  </select>
                </div>
  
                <table class="kc-co-multi-line-table">
                  <thead>
                    <tr>
                      <th class="header-left" width="420px">比較元コース名 (コースコード)<br>比較元アンケート名 (アンケートID)</th>
                      <th width="420px">比較先コース名 (コースコード)<br>比較先アンケート名 (アンケートID)</th>
                      <th width="90px">　</th>
                    </tr>
                  </thead>
                  <tbody> `;

html_format_end =  `
                  </tbody>
                </table>
                <div class="kc-co-pagination">
                  &nbsp;&nbsp;&nbsp;&nbsp;
                </div>
            </form>
  
          </div>
        </div>
  
      </div>
      
    <script type="text/JavaScript">
  
                function clearText() {
                  document.getElementById('searchMainBelongGroupCode').value = '';
                  document.getElementById('searchMainBelongGroupName').value = '';
                }
                function clearClass() {
                    $("#searchClassCode").val("");
                    $("#searchClassName").val("");
                }
            
        </script>
  
    <div class="kc-co-jqModal-wrap">
      <div class="kc-co-content-dialog kc-co-transition-dialog" id="transitionDialog" style="display:none;">
        <div class="kc-co-popup-outer kc-co-mb22">
          <h2 class="kc-co-ml20 kc-co-mt20" id="transitionTitle"></h2>
          <p class="kc-co-popup-content-text" id="transitionMessage"></p>
          <hr class="kc-co-bor-hr">
          <div class="kc-co-mt20 kc-co-align-center  kc-co-btn-yesno-align">
            <button class="kc-co-btn-yes-popup"
              onclick="submitForm(&#39;/icm/course-application/init-regist&#39;);return false;"
              type="button">OK</button>
          </div>
        </div>
      </div>
    </div>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    </div>
`;

enquetes = [
    {
        from : {
            code: "ABVPhatIN1",
            name: "TestReportSurvey01",
            enquete_code: 70,
            enquete_name: "ABV Internship Survey 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ABVPhatIN2",
            name: "TestReportSurvey02",
            enquete_code: 70,
            enquete_name: "ABV Internship Survey 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_code: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_code: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_code: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    }

]