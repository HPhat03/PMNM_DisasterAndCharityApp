onClosedModal = () => {
    $('#static-modal-group-search').fadeOut(200);
    $('#modal-group-search').css("display","none");
    $('#modal-class-search').css("display","none");
    $('#modal-group-search-result').css("display","none");
  }

onOpenModal = (id) => {
    $('#static-modal-group-search').fadeIn(200);
    $('#'+id).css("display","block");
  }

setSearchGrpKW = () => {
    kw = $('#searchKeyword').val()
    localStorage.setItem("grpKw", kw);
    $('#searchKeyword').val('');
}

onChangeModal = (id) => {
    $('#modal-group-search').css("display","none");
    $('#modal-class-search').css("display","none");
    $('#modal-group-search-result').css("display","none");

    $('#'+id).css("display","block");
    iframe = ($('#Grpiframe'))[0];

    onInitGroupSearch();
}

onInitGroupSearch = () => {
    gkw = localStorage.getItem('grpKw');
    $('#continueSearchKeyword').val(gkw);
}

confirmGrp = () => {
    rads = $('.radioGroupCode');
    index = 0;
    for(i = 0; i<rads.length; i++){
        if(rads[i].checked)
            index = rads[i].value;
    }

    $("#searchMainBelongGroupCode").val();
    $("#searchMainBelongGroupName").val($('#groupName[${index}]').val());
    onClosedModal();
}