lastportaldiv = 'ad'

{/* <tr class="kc-co-table-line-odd">
                    <td style="word-wrap:break-word;word-break:break-all;">
                      TestReportSurvey01 (ABVPhatIN1)
                    </td>
                    <td style="word-wrap:break-word;word-break:break-all;">
                      TestReportSurvey01 (ABVPhatIN1)
                    </td>

                    <td rowspan="2">
                      <div class="kc-co-td-button">
                        <div class="kc-co-btn-wrap2">
                          <div class="kc-co-btn-wrap1">
                            <div class="kc-co-btn">
                              <a href="javascript:void(0);"
                                onclick="enqResCmpValue(&#39&#39;,&#39;ABVPhatIN1&#39;,&#39;ABVPhatIN1&#39;,&#39;70&#39;,&#39;70&#39;);submitForm(&#39;/icm/enquete-result-compare/init-view&#39;);return false;"><button
                                  class="kc-co-btn-style kc-co-btn-style-text kc-co-btn-small"
                                  type="button">表示</button></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>

                  </tr>
                  <tr class="kc-co-table-line-odd">
                    <td>
                      ABV&nbsp;Internship&nbsp;Survey&nbsp;01 (70)
                    </td>
                    <td>
                      ABV&nbsp;Internship&nbsp;Survey&nbsp;01 (70)
                    </td>

                  </tr> */}

enquetes = [
    {
        from : {
            code: "ABVPhatIN1",
            name: "TestReportSurvey01",
            enquete_id: 70,
            enquete_name: "ABV Internship Survey 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ABVPhatIN2",
            name: "TestReportSurvey02",
            enquete_id: 70,
            enquete_name: "ABV Internship Survey 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_id: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        }
    },
    {
        from : {
            code: "ESCourse02",
            name: "ES Course 02",
            enquete_id: 71,
            enquete_name: "enquete Pager 01",
            group_code : "",
            group_name: ""
        },
        to : {
            code: "ESCourse01",
            name: "ES Course 01",
            enquete_id: 72,
            enquete_name: "enquete Pager 02",
            group_code : "",
            group_name: ""
        }
    }

]
